<!DOCTYPE html>

<html>

<head>
	<title>Car Rental</title>
</head>

<body>
	<div class="max-w-screen-xl mx-auto px-5">

		<?php require('templates/header.php'); ?>

		<!-- Hero -->
		<main class="grid lg:grid-cols-2 place-items-center pt-16 pb-8 md:pt-12 md:pb-24">
			<div class="py-6 md:order-1 hidden md:block">
				<picture>
					<img alt="Car photo here" src="assets/logo.jpeg">
				</picture>
			</div>
			<div>
				<h1 class="text-5xl lg:text-6xl xl:text-7xl font-bold lg:tracking-tight xl:tracking-tighter">
					Rent a car right now
				</h1>
				<p class="text-lg mt-4 text-slate-600 max-w-xl">
					Welcome to Car2Go, where innovation meets eco-conscious travel! We pride ourselves on being more than just a car rental company – we're your partners in sustainable mobility. Embrace a greener journey with our fleet of cutting-edge, eco-friendly vehicles that redefine the way you experience the open road.
				</p>
				<br>
				<p class="text-lg mt-4 text-slate-600 max-w-xl">
					Thank you for choosing Car2Go – where every ride is a step towards a greener tomorrow!
				</p>
				<div class="mt-6 flex flex-col sm:flex-row gap-3">
					<a href="#" target="_blank" rel="noopener" class="rounded text-center transition focus-visible:ring-2 ring-offset-2 ring-gray-200 px-5 py-1.5 bg-black text-white hover:bg-gray-800 border-2 border-transparent flex gap-1 items-center justify-center">
						Rent a car
					</a>
					<a href="#" rel="noopener" target="_blank" class="rounded text-center transition focus-visible:ring-2 ring-offset-2 ring-gray-200 px-5 py-1.5 bg-white border-2 border-black hover:bg-gray-100 text-black flex gap-1 items-center justify-center">
						Learn more
					</a>
				</div>
			</div>
		</main>

	</div>

	<script src="assets/js/tailwind.js"></script>
</body>

</html>